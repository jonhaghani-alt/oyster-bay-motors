/*
  # Create Vehicles Table for Inventory Management

  1. New Tables
    - `vehicles`
      - `id` (uuid, primary key) - Unique identifier for each vehicle
      - `year` (integer) - Vehicle year
      - `make` (text) - Vehicle manufacturer
      - `model` (text) - Vehicle model name
      - `trim` (text, optional) - Vehicle trim level
      - `price` (integer) - Vehicle price in dollars
      - `mileage` (integer) - Vehicle mileage
      - `exterior_color` (text) - Exterior color
      - `interior_color` (text) - Interior color
      - `transmission` (text) - Transmission type
      - `fuel_type` (text) - Fuel type
      - `body_style` (text) - Body style (sedan, suv, coupe, etc)
      - `vin` (text, optional) - Vehicle identification number
      - `stock_number` (text, optional) - Internal stock number
      - `description` (text, optional) - Detailed description
      - `features` (jsonb, optional) - Array of features
      - `images` (jsonb) - Array of image URLs
      - `status` (text) - Status (available, sold, pending)
      - `created_at` (timestamptz) - Creation timestamp
      - `updated_at` (timestamptz) - Last update timestamp

  2. Security
    - Enable RLS on `vehicles` table
    - Allow public read access for available vehicles
    - Restrict write access to authenticated admin users only
*/

CREATE TABLE IF NOT EXISTS vehicles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  year integer NOT NULL,
  make text NOT NULL,
  model text NOT NULL,
  trim text,
  price integer NOT NULL,
  mileage integer NOT NULL,
  exterior_color text NOT NULL,
  interior_color text NOT NULL,
  transmission text NOT NULL,
  fuel_type text NOT NULL,
  body_style text NOT NULL,
  vin text,
  stock_number text,
  description text,
  features jsonb DEFAULT '[]'::jsonb,
  images jsonb DEFAULT '[]'::jsonb,
  status text DEFAULT 'available' NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE vehicles ENABLE ROW LEVEL SECURITY;

-- Allow anyone to view available vehicles
CREATE POLICY "Anyone can view available vehicles"
  ON vehicles
  FOR SELECT
  USING (status = 'available');

-- Only authenticated users can insert vehicles
CREATE POLICY "Authenticated users can insert vehicles"
  ON vehicles
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Only authenticated users can update vehicles
CREATE POLICY "Authenticated users can update vehicles"
  ON vehicles
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Only authenticated users can delete vehicles
CREATE POLICY "Authenticated users can delete vehicles"
  ON vehicles
  FOR DELETE
  TO authenticated
  USING (true);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS vehicles_status_idx ON vehicles(status);
CREATE INDEX IF NOT EXISTS vehicles_created_at_idx ON vehicles(created_at DESC);