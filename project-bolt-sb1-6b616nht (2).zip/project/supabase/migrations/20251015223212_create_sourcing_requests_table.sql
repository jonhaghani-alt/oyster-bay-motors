/*
  # Create Car Sourcing Requests Table

  1. New Tables
    - `sourcing_requests`
      - `id` (uuid, primary key) - Unique identifier for the request
      - `created_at` (timestamptz) - When the request was submitted
      - `customer_name` (text) - Name of the customer
      - `customer_email` (text) - Email address for contact
      - `customer_phone` (text) - Phone number for contact
      - `vehicle_year` (text) - Year of requested vehicle
      - `vehicle_make` (text) - Make of requested vehicle
      - `vehicle_model` (text) - Model of requested vehicle
      - `vehicle_trim` (text, nullable) - Trim level if specified
      - `max_budget` (numeric) - Maximum budget for the vehicle
      - `max_mileage` (numeric, nullable) - Maximum acceptable mileage
      - `preferred_color` (text, nullable) - Preferred vehicle color
      - `additional_requirements` (text, nullable) - Any additional requirements
      - `agrees_to_sourcing_fee` (boolean) - Agreement to pay sourcing fees
      - `agrees_to_contract` (boolean) - Agreement to sign contract
      - `agrees_to_deposit` (boolean) - Agreement to pay deposit
      - `status` (text) - Status of request (pending, in_progress, completed, cancelled)
      - `notes` (text, nullable) - Internal notes from staff

  2. Security
    - Enable RLS on `sourcing_requests` table
    - Add policy for public insert (anyone can submit a request)
    - Add policy for authenticated users to view all requests (admin access)
*/

CREATE TABLE IF NOT EXISTS sourcing_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz DEFAULT now(),
  customer_name text NOT NULL,
  customer_email text NOT NULL,
  customer_phone text NOT NULL,
  vehicle_year text NOT NULL,
  vehicle_make text NOT NULL,
  vehicle_model text NOT NULL,
  vehicle_trim text,
  max_budget numeric NOT NULL,
  max_mileage numeric,
  preferred_color text,
  additional_requirements text,
  agrees_to_sourcing_fee boolean DEFAULT false,
  agrees_to_contract boolean DEFAULT false,
  agrees_to_deposit boolean DEFAULT false,
  status text DEFAULT 'pending',
  notes text
);

ALTER TABLE sourcing_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can submit sourcing request"
  ON sourcing_requests
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Authenticated users can view all requests"
  ON sourcing_requests
  FOR SELECT
  TO authenticated
  USING (true);