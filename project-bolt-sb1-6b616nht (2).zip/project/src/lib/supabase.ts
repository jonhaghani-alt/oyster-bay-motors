import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://nvoronavujzsrvjmyihg.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im52b3JvbmF2dWp6c3J2am15aWhnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjA1NDk3MjQsImV4cCI6MjA3NjEyNTcyNH0.G5cSE6bUAg4sksSadqAGSqn774fyE7dhO5Mv5F24-vU';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
