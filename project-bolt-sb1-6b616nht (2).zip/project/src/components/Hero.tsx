import { ArrowRight, Shield, ThumbsUp, Sparkles } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="relative bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 text-white">
      <div className="absolute inset-0 opacity-30">
        <img
          src="/HOMEPAGE OYSTER BAY WEBSITE.jpg"
          alt=""
          className="w-full h-full object-cover"
        />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 md:py-40">
        <div className="max-w-3xl">
          <div className="inline-flex items-center space-x-2 bg-blue-500/20 backdrop-blur-sm border border-blue-400/30 px-4 py-2 rounded-full mb-6">
            <Sparkles className="w-4 h-4 text-blue-300" />
            <span className="text-sm font-medium text-blue-100">Rare Classic Mercedes Specialists • Oyster Bay</span>
          </div>

          <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
            Discover Unique Classic Mercedes at Oyster Bay Motors
          </h1>

          <p className="text-xl md:text-2xl text-gray-300 mb-8 leading-relaxed">
            A family-owned business specializing in rare and unique classic Mercedes-Benz vehicles. Each car in our collection tells a story.
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <a href="#inventory" className="inline-flex items-center justify-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-lg font-semibold transition transform hover:scale-105 shadow-lg">
              <span>View Unique Classics</span>
              <ArrowRight className="w-5 h-5" />
            </a>

            <a href="#sell" className="inline-flex items-center justify-center space-x-2 bg-white/10 hover:bg-white/20 backdrop-blur-sm border border-white/30 text-white px-8 py-4 rounded-lg font-semibold transition">
              <span>Sell Your Car</span>
            </a>
          </div>

          <div className="grid grid-cols-3 gap-6 mt-16 pt-8 border-t border-white/20">
            <div className="flex flex-col items-center text-center">
              <Shield className="w-8 h-8 text-blue-400 mb-2" />
              <p className="text-sm text-gray-300">Quality Guaranteed</p>
            </div>
            <div className="flex flex-col items-center text-center">
              <ThumbsUp className="w-8 h-8 text-blue-400 mb-2" />
              <p className="text-sm text-gray-300">Fair Pricing</p>
            </div>
            <div className="flex flex-col items-center text-center">
              <Sparkles className="w-8 h-8 text-blue-400 mb-2" />
              <p className="text-sm text-gray-300">Unique Collection</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
