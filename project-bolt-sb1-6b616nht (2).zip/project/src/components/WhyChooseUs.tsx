import { Shield, Award, Users, Clock, CheckCircle, Star, Home } from 'lucide-react';

const features = [
  {
    icon: Home,
    title: 'Family-Owned Business',
    description: 'Proudly family-owned and operated, bringing you personal service and genuine care for every customer'
  },
  {
    icon: Shield,
    title: 'Quality Guaranteed',
    description: 'Every classic Mercedes undergoes thorough inspection to ensure authenticity and quality standards'
  },
  {
    icon: Award,
    title: 'Unique Mercedes Specialists',
    description: 'Curating rare and unique Mercedes-Benz vehicles that stand out from the ordinary'
  },
  {
    icon: Users,
    title: 'New Oyster Bay Location',
    description: 'Recently relocated to beautiful Oyster Bay. Visit our new showroom to see our collection'
  }
];

const testimonials = [
  {
    name: 'Robert Thompson',
    rating: 5,
    text: 'They helped me find a rare 280 SL Pagoda in pristine condition. Their collection of unique classics is unmatched!',
    vehicle: '1970 Mercedes 280 SL'
  },
  {
    name: 'Patricia Williams',
    rating: 5,
    text: 'Their expertise in rare Mercedes models is exceptional. Found a unique W123 300D that I couldn\'t find anywhere else!',
    vehicle: '1984 Mercedes W123 300D'
  },
  {
    name: 'James Martinez',
    rating: 5,
    text: 'Every vehicle in their collection is special and unique. They really understand what collectors are looking for.',
    vehicle: '1988 Mercedes 560 SEC'
  }
];

export default function WhyChooseUs() {
  return (
    <section id="about" className="py-24 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Why Choose Oyster Bay Motors?
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            A family tradition of excellence, now serving Oyster Bay with rare and unique Mercedes-Benz automobiles
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {features.map((feature, index) => (
            <div key={index} className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition">
              <div className="w-14 h-14 bg-blue-100 rounded-lg flex items-center justify-center mb-6">
                <feature.icon className="w-7 h-7 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                {feature.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        <div className="bg-blue-600 rounded-2xl p-12 text-white mb-20">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold mb-2">25+</div>
              <div className="text-blue-100">Years Family Business</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">500+</div>
              <div className="text-blue-100">Unique Mercedes Sold</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">New</div>
              <div className="text-blue-100">Oyster Bay Location</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">5.0★</div>
              <div className="text-blue-100">Customer Rating</div>
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-3xl font-bold text-gray-900 text-center mb-12">
            What Our Customers Say
          </h3>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white p-8 rounded-xl shadow-lg">
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 mb-6 leading-relaxed italic">
                  "{testimonial.text}"
                </p>
                <div className="border-t pt-4">
                  <p className="font-semibold text-gray-900">{testimonial.name}</p>
                  <p className="text-sm text-gray-600">{testimonial.vehicle}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
