import { CarFront, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center shadow-lg">
                <CarFront className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold">Oyster Bay Motors</h3>
                <p className="text-sm text-gray-400">Family-Owned Since 1998</p>
              </div>
            </div>
            <p className="text-gray-400 mb-6 leading-relaxed">
              A family-owned business specializing in classic Mercedes-Benz automobiles. Recently relocated to our new Oyster Bay showroom.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 bg-slate-800 hover:bg-blue-600 rounded-full flex items-center justify-center transition">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-slate-800 hover:bg-blue-600 rounded-full flex items-center justify-center transition">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-slate-800 hover:bg-blue-600 rounded-full flex items-center justify-center transition">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-slate-800 hover:bg-blue-600 rounded-full flex items-center justify-center transition">
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><a href="#home" className="text-gray-400 hover:text-white transition">Home</a></li>
              <li><a href="#inventory" className="text-gray-400 hover:text-white transition">Inventory</a></li>
              <li><a href="#sell" className="text-gray-400 hover:text-white transition">Sell Your Car</a></li>
              <li><a href="#about" className="text-gray-400 hover:text-white transition">About Us</a></li>
              <li><a href="#contact" className="text-gray-400 hover:text-white transition">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Services</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-white transition">Buy a Car</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition">Sell Your Car</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition">Trade-In</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition">Financing</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition">Warranty</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-800 mt-12 pt-8 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Oyster Bay Motors. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
