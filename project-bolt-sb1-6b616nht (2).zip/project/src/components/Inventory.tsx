import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Gauge, Calendar, Fuel, MapPin, Heart, ExternalLink, Star, Zap } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Vehicle {
  id: string;
  year: number;
  make: string;
  model: string;
  price: number;
  mileage: number;
  fuel_type: string;
  transmission: string;
  images: string[];
  body_style: string;
}

export default function Inventory() {
  const [category, setCategory] = useState<'unique' | 'everyday'>('unique');
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    loadVehicles();
  }, []);

  const loadVehicles = async () => {
    try {
      const { data, error } = await supabase
        .from('vehicles')
        .select('*')
        .eq('status', 'available')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error loading vehicles:', error);
        setVehicles([]);
      } else {
        setVehicles(data || []);
      }
    } catch (error) {
      console.error('Error loading vehicles:', error);
      setVehicles([]);
    } finally {
      setLoading(false);
    }
  };

  const uniqueVehicles = vehicles.filter(v =>
    v.body_style === 'Coupe' || v.body_style === 'Convertible' || v.year < 2000
  );

  const everydayVehicles = vehicles.filter(v =>
    (v.body_style === 'Sedan' || v.body_style === 'SUV') && v.year >= 2000
  );

  const displayVehicles = category === 'unique' ? uniqueVehicles : everydayVehicles;

  if (loading) {
    return (
      <section id="inventory" className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600">Loading inventory...</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="inventory" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Our Inventory
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            From rare classics to reliable daily drivers, find your perfect vehicle
          </p>
        </div>

        <div className="flex justify-center mb-12">
          <div className="inline-flex bg-white rounded-lg shadow-lg p-1.5 gap-2">
            <button
              onClick={() => setCategory('unique')}
              className={`px-8 py-4 rounded-lg font-semibold transition-all flex items-center space-x-2 ${
                category === 'unique'
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-md'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <Star className="w-5 h-5" />
              <span>Unique Classics</span>
            </button>
            <button
              onClick={() => setCategory('everyday')}
              className={`px-8 py-4 rounded-lg font-semibold transition-all flex items-center space-x-2 ${
                category === 'everyday'
                  ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-md'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <Zap className="w-5 h-5" />
              <span>Everyday Drivers</span>
            </button>
          </div>
        </div>

        <div className="mb-8 text-center">
          <div className={`inline-block px-6 py-3 rounded-full font-medium ${
            category === 'unique'
              ? 'bg-amber-100 text-amber-900 border border-amber-300'
              : 'bg-blue-100 text-blue-900 border border-blue-300'
          }`}>
            {category === 'unique'
              ? 'Rare & Collectible Vehicles'
              : 'Reliable Vehicles for Daily Use'}
          </div>
        </div>

        {displayVehicles.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl shadow-lg">
            <p className="text-gray-600 text-lg">No vehicles in this category yet</p>
            <p className="text-sm text-gray-500 mt-2">Check back soon for new inventory</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {displayVehicles.map((vehicle) => (
              <div key={vehicle.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition transform hover:-translate-y-1">
                <div className="relative">
                  {vehicle.images.length > 0 ? (
                    <img
                      src={vehicle.images[0]}
                      alt={`${vehicle.year} ${vehicle.make} ${vehicle.model}`}
                      className="w-full h-56 object-cover"
                    />
                  ) : (
                    <div className="w-full h-56 bg-gray-200 flex items-center justify-center">
                      <Gauge className="w-16 h-16 text-gray-400" />
                    </div>
                  )}
                  {category === 'unique' && (
                    <div className="absolute top-4 right-4 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-3 py-1 rounded-full text-sm font-semibold flex items-center space-x-1">
                      <Star className="w-4 h-4" />
                      <span>Classic</span>
                    </div>
                  )}
                  <button className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm p-2 rounded-full hover:bg-white transition">
                    <Heart className="w-5 h-5 text-gray-700" />
                  </button>
                </div>

                <div className="p-6">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">
                    {vehicle.year} {vehicle.make} {vehicle.model}
                  </h3>

                  <div className="text-3xl font-bold text-blue-600 mb-4">
                    ${vehicle.price.toLocaleString()}
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="flex items-center space-x-2 text-gray-600">
                      <Gauge className="w-4 h-4" />
                      <span className="text-sm">{vehicle.mileage.toLocaleString()} mi</span>
                    </div>
                    <div className="flex items-center space-x-2 text-gray-600">
                      <Calendar className="w-4 h-4" />
                      <span className="text-sm">{vehicle.year}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-gray-600">
                      <Fuel className="w-4 h-4" />
                      <span className="text-sm">{vehicle.fuel_type}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-gray-600">
                      <MapPin className="w-4 h-4" />
                      <span className="text-sm">{vehicle.transmission}</span>
                    </div>
                  </div>

                  <button
                    onClick={() => navigate(`/vehicle/${vehicle.id}`)}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold transition flex items-center justify-center space-x-2"
                  >
                    <span>View Details</span>
                    <ExternalLink className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="text-center mt-12">
          <p className="text-gray-600 mb-4">Can't find what you're looking for?</p>
          <a href="#contact" className="inline-flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold">
            <span>Contact us for more options</span>
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>
      </div>
    </section>
  );
}
