import { Wrench, Car, FileCheck, Zap, Phone, CheckCircle, ArrowRight } from 'lucide-react';

const services = [
  {
    icon: Car,
    title: 'Foreign & Classic Vehicle Sales',
    description: 'Expertly curated selection of rare and unique foreign vehicles. From European classics to Japanese imports, each vehicle is handpicked for quality and authenticity.',
    features: ['Authenticated vehicles', 'Complete history reports', 'Pre-delivery inspection']
  },
  {
    icon: FileCheck,
    title: 'Vehicle Consignment',
    description: 'Let us sell your foreign or classic vehicle. We handle marketing, showings, and paperwork while you get top dollar for your vehicle.',
    features: ['Professional photography', 'Targeted marketing', 'Secure transactions']
  },
  {
    icon: Wrench,
    title: 'Pre-Purchase Inspections',
    description: 'Considering a foreign or classic vehicle? Our comprehensive inspections give you peace of mind before making your investment.',
    features: ['Mechanical assessment', 'Authenticity verification', 'Detailed reports']
  },
  {
    icon: Zap,
    title: 'Vehicle Sourcing',
    description: 'Looking for a specific foreign or classic vehicle? We leverage our network to find exactly what you want, anywhere in the country.',
    features: ['Nationwide search', 'Authentication services', 'Transportation arranged']
  }
];

const process = [
  {
    step: '01',
    title: 'Consultation',
    description: 'Discuss your needs, preferences, and budget with our foreign and classic vehicle specialists'
  },
  {
    step: '02',
    title: 'Selection',
    description: 'We present curated options from our inventory or source your dream vehicle'
  },
  {
    step: '03',
    title: 'Inspection',
    description: 'Comprehensive review of vehicle condition, authenticity, and documentation'
  },
  {
    step: '04',
    title: 'Delivery',
    description: 'Secure transaction, paperwork handled, and your vehicle delivered'
  }
];

export default function Services() {
  return (
    <section id="services" className="py-24 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-blue-100 px-4 py-2 rounded-full mb-4">
            <Wrench className="w-4 h-4 text-blue-600" />
            <span className="text-sm font-semibold text-blue-600">Our Services</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Comprehensive Foreign & Classic Vehicle Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            From finding your dream foreign or classic vehicle to selling your current car, we provide end-to-end services for automotive enthusiasts
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-24">
          {services.map((service, index) => (
            <div key={index} className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition group">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition">
                <service.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-3">
                {service.title}
              </h3>
              <p className="text-gray-600 leading-relaxed mb-6">
                {service.description}
              </p>
              <ul className="space-y-3">
                {service.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center text-gray-700">
                    <CheckCircle className="w-5 h-5 text-blue-600 mr-3 flex-shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 rounded-3xl p-12 md:p-16 text-white mb-24">
          <div className="text-center mb-12">
            <h3 className="text-3xl md:text-4xl font-bold mb-4">Our Process</h3>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              A simple, transparent approach to helping you buy or sell foreign and classic vehicles
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {process.map((item, index) => (
              <div key={index} className="relative">
                <div className="text-center">
                  <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold">
                    {item.step}
                  </div>
                  <h4 className="text-xl font-bold mb-3">{item.title}</h4>
                  <p className="text-gray-300 leading-relaxed">
                    {item.description}
                  </p>
                </div>
                {index < process.length - 1 && (
                  <div className="hidden md:block absolute top-10 left-[60%] w-[80%] h-0.5 bg-blue-600/30"></div>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-10 text-center">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">
            Ready to Get Started?
          </h3>
          <p className="text-xl text-gray-700 mb-8 max-w-2xl mx-auto">
            Whether you're buying your first foreign classic or selling your treasured vehicle, we're here to help every step of the way.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="tel:+15162261253"
              className="inline-flex items-center justify-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-lg font-semibold transition transform hover:scale-105 shadow-lg"
            >
              <Phone className="w-5 h-5" />
              <span>(516) 226-1253</span>
            </a>
            <a
              href="#contact"
              className="inline-flex items-center justify-center space-x-2 bg-white hover:bg-gray-50 text-blue-600 border-2 border-blue-600 px-8 py-4 rounded-lg font-semibold transition"
            >
              <span>Contact Us Online</span>
              <ArrowRight className="w-5 h-5" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
