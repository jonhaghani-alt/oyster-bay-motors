import { DollarSign, Clock, FileCheck, TrendingUp, ArrowRight } from 'lucide-react';

export default function SellYourCar() {
  return (
    <section id="sell" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-flex items-center space-x-2 bg-green-100 text-green-700 px-4 py-2 rounded-full mb-6">
              <TrendingUp className="w-4 h-4" />
              <span className="text-sm font-medium">Top Dollar for Your Vehicle</span>
            </div>

            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Sell Your Car the Easy Way
            </h2>

            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              Get a fair, competitive offer for your vehicle in minutes. Our simple process makes selling your car hassle-free, with instant evaluations and fast payment.
            </p>

            <div className="space-y-6 mb-8">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <FileCheck className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">1. Get Your Quote</h3>
                  <p className="text-gray-600">Fill out our simple form with your vehicle details and get an instant estimate</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Clock className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">2. Schedule Inspection</h3>
                  <p className="text-gray-600">Choose a convenient time for our team to inspect your vehicle</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">3. Get Paid Fast</h3>
                  <p className="text-gray-600">Accept our offer and receive payment within 24 hours</p>
                </div>
              </div>
            </div>

            <a href="#contact" className="inline-flex items-center space-x-2 bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-lg font-semibold transition transform hover:scale-105 shadow-lg">
              <span>Get Your Free Quote</span>
              <ArrowRight className="w-5 h-5" />
            </a>
          </div>

          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://images.pexels.com/photos/3752169/pexels-photo-3752169.jpeg"
                alt="Sell your car"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-xl">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                  <DollarSign className="w-8 h-8 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Average Payout</p>
                  <p className="text-2xl font-bold text-gray-900">$24,500</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
