import { useState } from 'react';
import { Search, DollarSign, Gauge, FileText, CheckCircle, AlertCircle, Phone, CarFront } from 'lucide-react';
import { supabase } from '../lib/supabase';
import Footer from './Footer';

export default function CarSourcing() {
  const [formData, setFormData] = useState({
    customer_name: '',
    customer_email: '',
    customer_phone: '',
    vehicle_year: '',
    vehicle_make: '',
    vehicle_model: '',
    vehicle_trim: '',
    max_budget: '',
    max_mileage: '',
    preferred_color: '',
    additional_requirements: '',
    agrees_to_sourcing_fee: false,
    agrees_to_contract: false,
    agrees_to_deposit: false,
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.agrees_to_sourcing_fee || !formData.agrees_to_contract || !formData.agrees_to_deposit) {
      setErrorMessage('You must agree to all terms to submit a sourcing request.');
      setSubmitStatus('error');
      return;
    }

    setIsSubmitting(true);
    setSubmitStatus('idle');
    setErrorMessage('');

    try {
      const requestData = {
        ...formData,
        max_budget: parseFloat(formData.max_budget),
        max_mileage: formData.max_mileage ? parseInt(formData.max_mileage) : null,
      };

      const { error } = await supabase.from('sourcing_requests').insert([requestData]);

      if (error) throw error;

      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-sourcing-email`;
      await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestData),
      });

      setSubmitStatus('success');
      setFormData({
        customer_name: '',
        customer_email: '',
        customer_phone: '',
        vehicle_year: '',
        vehicle_make: '',
        vehicle_model: '',
        vehicle_trim: '',
        max_budget: '',
        max_mileage: '',
        preferred_color: '',
        additional_requirements: '',
        agrees_to_sourcing_fee: false,
        agrees_to_contract: false,
        agrees_to_deposit: false,
      });
    } catch (error) {
      console.error('Error submitting request:', error);
      setErrorMessage('Failed to submit your request. Please try again.');
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 50 }, (_, i) => currentYear - i);

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white/95 backdrop-blur-sm shadow-sm z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <a href="/" className="flex items-center space-x-3">
              <div className="relative">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center shadow-lg">
                  <CarFront className="w-7 h-7 text-white" />
                </div>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Oyster Bay Motors</h1>
                <p className="text-xs text-gray-600">Premium Auto Sales</p>
              </div>
            </a>

            <div className="hidden md:flex space-x-8">
              <a href="/" className="text-gray-700 hover:text-blue-600 transition">Home</a>
              <a href="/#inventory" className="text-gray-700 hover:text-blue-600 transition">Inventory</a>
              <a href="/#services" className="text-gray-700 hover:text-blue-600 transition">Services</a>
              <a href="/sourcing" className="text-blue-600 font-semibold">Source a Car</a>
              <a href="/#sell" className="text-gray-700 hover:text-blue-600 transition">Sell Your Car</a>
              <a href="/#about" className="text-gray-700 hover:text-blue-600 transition">About</a>
              <a href="/#contact" className="text-gray-700 hover:text-blue-600 transition">Contact</a>
            </div>

            <a href="tel:+15162261253" className="hidden md:flex items-center space-x-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition">
              <Phone className="w-4 h-4" />
              <span className="font-semibold">(516) 226-1253</span>
            </a>
          </div>
        </div>
      </nav>

      <section className="relative pt-20 bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 text-white">
        <div className="absolute inset-0 bg-[url('/homepage%20background%20oyster%20bay%20%20copy.webp')] bg-cover bg-center opacity-30"></div>

        <div className="relative h-96 flex items-center justify-center text-center px-4">
          <div>
            <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-500/20 backdrop-blur-sm border border-blue-400/30 rounded-full mb-6">
              <Search className="w-10 h-10 text-blue-300" />
            </div>
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-4">
              Vehicle Sourcing Service
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Can't find the perfect vehicle in our inventory? Let us source it for you.
            </p>
          </div>
        </div>
      </section>

      <section className="py-24 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            <div className="relative h-48 rounded-lg overflow-hidden shadow-lg">
              <img src="/IMG_3041.jpeg" alt="Mercedes" className="w-full h-full object-cover" />
            </div>
            <div className="relative h-48 rounded-lg overflow-hidden shadow-lg">
              <img src="/IMG_3019.jpeg" alt="Mercedes" className="w-full h-full object-cover" />
            </div>
            <div className="relative h-48 rounded-lg overflow-hidden shadow-lg">
              <img src="/IMG_3038.jpeg" alt="Mercedes" className="w-full h-full object-cover" />
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12 mb-8">
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Our Sourcing Network</h2>
              <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-8 mb-8">
              <p className="text-gray-700 leading-relaxed mb-4">
                At Oyster Bay Motors, we leverage an extensive network of automotive resources to locate the exact vehicle you're searching for. Our comprehensive sourcing system gives us unparalleled access to both public and private markets nationwide.
              </p>
              <div className="grid md:grid-cols-2 gap-6 mt-6">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                    <Search className="w-5 h-5 text-blue-600 mr-2" />
                    Auction Platforms
                  </h4>
                  <p className="text-gray-700 text-sm leading-relaxed">
                    We actively monitor and bid on every major automotive auction platform including Manheim, ADESA, Copart, IAA, and specialized dealer-only auctions. Our dealer credentials provide access to wholesale inventory that the general public cannot reach.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                    <Gauge className="w-5 h-5 text-blue-600 mr-2" />
                    Private Network
                  </h4>
                  <p className="text-gray-700 text-sm leading-relaxed">
                    Beyond auctions, we've cultivated relationships with private sellers, collectors, estate sales, and other dealerships across the country. Our proprietary sourcing system tracks off-market vehicles and upcoming listings before they reach the public marketplace.
                  </p>
                </div>
              </div>
            </div>

              <h2 className="text-2xl font-bold text-gray-900 mb-6">How It Works</h2>
              <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-blue-600 font-bold text-xl">1</span>
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Submit Request</h3>
                <p className="text-gray-600 text-sm">Tell us exactly what you're looking for</p>
              </div>
              <div className="text-center">
                <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-blue-600 font-bold text-xl">2</span>
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Sign Contract</h3>
                <p className="text-gray-600 text-sm">Review terms and provide deposit</p>
              </div>
              <div className="text-center">
                <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-blue-600 font-bold text-xl">3</span>
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">We Find It</h3>
                <p className="text-gray-600 text-sm">We leverage our extensive network to source your perfect vehicle</p>
              </div>
            </div>
          </div>

            <div className="bg-amber-50 border border-amber-200 rounded-lg p-6 mb-8">
            <h3 className="font-semibold text-amber-900 mb-3 flex items-center">
              <DollarSign className="w-5 h-5 mr-2" />
              Sourcing Fee & Terms
            </h3>
            <ul className="space-y-2 text-amber-900 text-sm">
              <li className="flex items-start">
                <span className="mr-2">•</span>
                <span>A sourcing fee applies to cover our search and acquisition costs</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2">•</span>
                <span>A signed contract is required before we begin the search</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2">•</span>
                <span>A deposit is required to secure our services and begin the search process</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2">•</span>
                <span>We'll contact you within 24 hours to discuss specific fees and terms</span>
              </li>
            </ul>
          </div>

            <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Your Information</h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    name="customer_name"
                    value={formData.customer_name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    name="customer_email"
                    value={formData.customer_email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    name="customer_phone"
                    value={formData.customer_phone}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
            </div>

            <div className="border-t pt-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Vehicle Requirements</h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Year *
                  </label>
                  <select
                    name="vehicle_year"
                    value={formData.vehicle_year}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Select Year</option>
                    {years.map(year => (
                      <option key={year} value={year}>{year}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Make *
                  </label>
                  <input
                    type="text"
                    name="vehicle_make"
                    value={formData.vehicle_make}
                    onChange={handleChange}
                    required
                    placeholder="e.g., Mercedes-Benz"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Model *
                  </label>
                  <input
                    type="text"
                    name="vehicle_model"
                    value={formData.vehicle_model}
                    onChange={handleChange}
                    required
                    placeholder="e.g., E-Class"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Trim
                  </label>
                  <input
                    type="text"
                    name="vehicle_trim"
                    value={formData.vehicle_trim}
                    onChange={handleChange}
                    placeholder="e.g., AMG, Sport"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Maximum Budget * ($)
                  </label>
                  <input
                    type="number"
                    name="max_budget"
                    value={formData.max_budget}
                    onChange={handleChange}
                    required
                    min="0"
                    step="100"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Maximum Mileage
                  </label>
                  <input
                    type="number"
                    name="max_mileage"
                    value={formData.max_mileage}
                    onChange={handleChange}
                    min="0"
                    step="1000"
                    placeholder="Optional"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Preferred Color
                  </label>
                  <input
                    type="text"
                    name="preferred_color"
                    value={formData.preferred_color}
                    onChange={handleChange}
                    placeholder="e.g., Black, Silver, White"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Additional Requirements
                  </label>
                  <textarea
                    name="additional_requirements"
                    value={formData.additional_requirements}
                    onChange={handleChange}
                    rows={4}
                    placeholder="Tell us about any specific features, condition requirements, or other preferences..."
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
            </div>

            <div className="border-t pt-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                <FileText className="w-5 h-5 mr-2" />
                Terms & Agreement
              </h3>
              <div className="space-y-4 bg-gray-50 p-6 rounded-lg">
                <label className="flex items-start cursor-pointer">
                  <input
                    type="checkbox"
                    name="agrees_to_sourcing_fee"
                    checked={formData.agrees_to_sourcing_fee}
                    onChange={handleChange}
                    className="mt-1 mr-3 h-5 w-5 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <span className="text-gray-700">
                    I understand and agree to pay the applicable sourcing fee for this service *
                  </span>
                </label>
                <label className="flex items-start cursor-pointer">
                  <input
                    type="checkbox"
                    name="agrees_to_contract"
                    checked={formData.agrees_to_contract}
                    onChange={handleChange}
                    className="mt-1 mr-3 h-5 w-5 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <span className="text-gray-700">
                    I agree to sign a contract before the sourcing process begins *
                  </span>
                </label>
                <label className="flex items-start cursor-pointer">
                  <input
                    type="checkbox"
                    name="agrees_to_deposit"
                    checked={formData.agrees_to_deposit}
                    onChange={handleChange}
                    className="mt-1 mr-3 h-5 w-5 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <span className="text-gray-700">
                    I agree to provide the required deposit to secure this sourcing service *
                  </span>
                </label>
              </div>
            </div>

            {submitStatus === 'success' && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-start">
                <CheckCircle className="w-5 h-5 text-green-600 mr-3 mt-0.5" />
                <div>
                  <p className="text-green-900 font-semibold">Request Submitted Successfully!</p>
                  <p className="text-green-700 text-sm mt-1">
                    We'll contact you within 24 hours to discuss the details and next steps.
                  </p>
                </div>
              </div>
            )}

            {submitStatus === 'error' && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start">
                <AlertCircle className="w-5 h-5 text-red-600 mr-3 mt-0.5" />
                <div>
                  <p className="text-red-900 font-semibold">Error</p>
                  <p className="text-red-700 text-sm mt-1">{errorMessage}</p>
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white py-4 rounded-lg font-semibold transition flex items-center justify-center space-x-2"
            >
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>Submitting...</span>
                </>
              ) : (
                <>
                  <Search className="w-5 h-5" />
                  <span>Submit Sourcing Request</span>
                </>
              )}
            </button>
            </form>
          </div>

          <div className="text-center text-gray-600">
            <p className="mb-2">Questions about our sourcing service?</p>
            <a href="/#contact" className="text-blue-600 hover:text-blue-700 font-semibold">
              Contact us directly
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
