import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Phone, Mail, Gauge, Calendar, Fuel, MapPin, CheckCircle, Star, Shield, Award, Clock } from 'lucide-react';

const vehicles = [
  {
    id: 1,
    year: 1971,
    make: 'Mercedes-Benz',
    model: '280SEL',
    price: 32500,
    mileage: '44,000',
    fuel: 'Gasoline',
    transmission: 'Automatic',
    exterior: 'Red',
    interior: 'Black Leather',
    vin: 'Available upon request',
    image: '/IMG_3003.jpeg',
    images: [
      '/IMG_3003.jpeg',
      '/IMG_3010.jpeg',
      '/IMG_3011.jpeg',
      '/IMG_3042.jpeg',
      '/IMG_3043.jpeg',
      '/IMG_3044.jpeg',
      '/IMG_3019 copy.jpeg',
      '/IMG_3041 copy copy copy copy copy.jpeg'
    ],
    description: 'This stunning 1971 Mercedes-Benz 280SEL represents the pinnacle of classic German engineering. With only 44,000 original miles, this rare classic sedan has been meticulously maintained and is ready for its next discerning owner.',
    highlights: [
      'Only 44,000 original miles',
      'Well-preserved original condition',
      'Classic red over black leather interior',
      'Smooth-running inline-6 engine',
      'Recent service and inspection',
      'Clean title and documentation',
      'Iconic W108 chassis design',
      'Highly collectible classic Mercedes'
    ],
    whyBuyFromUs: [
      {
        icon: Shield,
        title: 'Authenticated & Inspected',
        description: 'Every vehicle undergoes thorough inspection and authentication before being offered for sale.'
      },
      {
        icon: Award,
        title: 'Quality Guarantee',
        description: 'We stand behind our vehicles with comprehensive pre-delivery service and transparent history.'
      },
      {
        icon: Clock,
        title: 'Expert Knowledge',
        description: 'Over 20 years of experience specializing in classic and foreign vehicles.'
      }
    ]
  }
];

export default function VehicleDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [selectedImage, setSelectedImage] = useState(0);

  const vehicle = vehicles.find(v => v.id === Number(id));

  if (!vehicle) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Vehicle not found</h2>
          <button
            onClick={() => navigate('/')}
            className="text-blue-600 hover:text-blue-700 font-semibold"
          >
            Return to homepage
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <button
            onClick={() => navigate('/')}
            className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="font-semibold">Back to Inventory</span>
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-2 gap-12">
          <div>
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-6">
              <div className="relative aspect-[4/3]">
                <img
                  src={vehicle.images[selectedImage]}
                  alt={`${vehicle.year} ${vehicle.make} ${vehicle.model}`}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 right-4 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-full text-sm font-semibold flex items-center space-x-1">
                  <Star className="w-4 h-4" />
                  <span>Classic</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-5 gap-3">
              {vehicle.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImage(idx)}
                  className={`rounded-lg overflow-hidden border-2 transition ${
                    selectedImage === idx
                      ? 'border-blue-600 shadow-md'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <img
                    src={img}
                    alt={`View ${idx + 1}`}
                    className="w-full aspect-square object-cover"
                  />
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="bg-white rounded-2xl shadow-lg p-8 mb-6">
              <h1 className="text-4xl font-bold text-gray-900 mb-2">
                {vehicle.year} {vehicle.make} {vehicle.model}
              </h1>

              <div className="text-4xl font-bold text-blue-600 mb-6">
                ${vehicle.price.toLocaleString()}
              </div>

              <div className="grid grid-cols-2 gap-4 mb-8">
                <div className="flex items-center space-x-3 text-gray-700">
                  <Gauge className="w-5 h-5 text-blue-600" />
                  <div>
                    <div className="text-sm text-gray-500">Mileage</div>
                    <div className="font-semibold">{vehicle.mileage} mi</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3 text-gray-700">
                  <Calendar className="w-5 h-5 text-blue-600" />
                  <div>
                    <div className="text-sm text-gray-500">Year</div>
                    <div className="font-semibold">{vehicle.year}</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3 text-gray-700">
                  <Fuel className="w-5 h-5 text-blue-600" />
                  <div>
                    <div className="text-sm text-gray-500">Fuel Type</div>
                    <div className="font-semibold">{vehicle.fuel}</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3 text-gray-700">
                  <MapPin className="w-5 h-5 text-blue-600" />
                  <div>
                    <div className="text-sm text-gray-500">Transmission</div>
                    <div className="font-semibold">{vehicle.transmission}</div>
                  </div>
                </div>
              </div>

              <div className="border-t pt-6 mb-6">
                <h3 className="font-semibold text-gray-900 mb-3">Additional Details</h3>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="text-gray-500">Exterior:</span>
                    <span className="ml-2 font-medium">{vehicle.exterior}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Interior:</span>
                    <span className="ml-2 font-medium">{vehicle.interior}</span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-gray-500">VIN:</span>
                    <span className="ml-2 font-medium">{vehicle.vin}</span>
                  </div>
                </div>
              </div>

              <div className="flex flex-col gap-3">
                <a
                  href="tel:+15162261253"
                  className="flex items-center justify-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-lg font-semibold transition shadow-lg"
                >
                  <Phone className="w-5 h-5" />
                  <span>Call (516) 226-1253</span>
                </a>
                <a
                  href="#contact"
                  onClick={(e) => {
                    e.preventDefault();
                    navigate('/#contact');
                  }}
                  className="flex items-center justify-center space-x-2 bg-white hover:bg-gray-50 text-blue-600 border-2 border-blue-600 py-4 rounded-lg font-semibold transition"
                >
                  <Mail className="w-5 h-5" />
                  <span>Contact Us Online</span>
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">About This Vehicle</h2>
              <p className="text-gray-700 leading-relaxed mb-6">
                {vehicle.description}
              </p>

              <h3 className="text-xl font-bold text-gray-900 mb-4">Key Highlights</h3>
              <div className="grid md:grid-cols-2 gap-3">
                {vehicle.highlights.map((highlight, idx) => (
                  <div key={idx} className="flex items-start space-x-3">
                    <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">{highlight}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div>
            <div className="bg-gradient-to-br from-slate-900 to-blue-900 rounded-2xl shadow-lg p-8 text-white">
              <h2 className="text-2xl font-bold mb-6">Why Buy From Oyster Bay Motors?</h2>

              {vehicle.whyBuyFromUs.map((reason, idx) => (
                <div key={idx} className="mb-6 last:mb-0">
                  <div className="flex items-start space-x-3">
                    <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
                      <reason.icon className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-1">{reason.title}</h3>
                      <p className="text-gray-300 text-sm">{reason.description}</p>
                    </div>
                  </div>
                </div>
              ))}

              <div className="mt-8 pt-6 border-t border-blue-800">
                <p className="text-sm text-gray-300 mb-4">
                  Located in Oyster Bay, serving Long Island and the tri-state area for over 20 years.
                </p>
                <div className="flex items-center space-x-2 text-sm">
                  <Phone className="w-4 h-4" />
                  <span>(516) 226-1253</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
