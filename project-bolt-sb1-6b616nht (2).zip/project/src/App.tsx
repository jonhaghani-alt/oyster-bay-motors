import { useState } from 'react';
import { Phone, Mail, MapPin, ArrowRight, Check, Star, CarFront } from 'lucide-react';
import Hero from './components/Hero';
import Inventory from './components/Inventory';
import SellYourCar from './components/SellYourCar';
import Services from './components/Services';
import WhyChooseUs from './components/WhyChooseUs';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  const [activeSection, setActiveSection] = useState('home');

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white/95 backdrop-blur-sm shadow-sm z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center shadow-lg">
                  <CarFront className="w-7 h-7 text-white" />
                </div>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Oyster Bay Motors</h1>
                <p className="text-xs text-gray-600">Premium Auto Sales</p>
              </div>
            </div>

            <div className="hidden md:flex space-x-8">
              <a href="#home" className="text-gray-700 hover:text-blue-600 transition">Home</a>
              <a href="#inventory" className="text-gray-700 hover:text-blue-600 transition">Inventory</a>
              <a href="#services" className="text-gray-700 hover:text-blue-600 transition">Services</a>
              <a href="/sourcing" className="text-gray-700 hover:text-blue-600 transition">Source a Car</a>
              <a href="#sell" className="text-gray-700 hover:text-blue-600 transition">Sell Your Car</a>
              <a href="#about" className="text-gray-700 hover:text-blue-600 transition">About</a>
              <a href="#contact" className="text-gray-700 hover:text-blue-600 transition">Contact</a>
            </div>

            <a href="tel:+15162261253" className="hidden md:flex items-center space-x-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition">
              <Phone className="w-4 h-4" />
              <span className="font-semibold">(516) 226-1253</span>
            </a>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="pt-20">
        <Hero />
        <Inventory />
        <Services />
        <SellYourCar />
        <WhyChooseUs />
        <Contact />
      </main>

      <Footer />
    </div>
  );
}

export default App;
